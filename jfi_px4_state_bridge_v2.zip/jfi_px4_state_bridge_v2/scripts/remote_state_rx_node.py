#!/usr/bin/env python3
"""SUV-LAB J.Fi packet RX -> remote UAV state publisher/logger.

This node logs ONLY packets received through J.Fi from other UAVs.
It does not log the local PX4 state.

Flow:
  J.Fi module -> serial_comm_node -> /jfi_comm/out/packet --subscribe-->
  remote_state_rx_node -> /swarm/uavXX/state + CSV logging
"""

import csv
import os
import struct
from dataclasses import dataclass
from typing import Dict, List

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray
from jfi_comm.msg import SwarmComm

MAGIC = 0x4A46  # 'JF'
VERSION = 1
STATE_STRUCT = struct.Struct('<HBBIQffffff')


@dataclass
class StatePacket:
    uav_id: int
    state_seq: int
    px4_timestamp_us: int
    x: float
    y: float
    z: float
    roll: float
    pitch: float
    yaw: float


def parse_peer_ids(value) -> List[int]:
    if value is None:
        return []
    if isinstance(value, (list, tuple)):
        out = []
        for item in value:
            try:
                out.append(int(item))
            except Exception:
                pass
        return out
    text = str(value).strip()
    if not text:
        return []
    out = []
    for token in text.replace(';', ',').split(','):
        token = token.strip()
        if not token:
            continue
        try:
            out.append(int(token))
        except ValueError:
            pass
    return out


def decode_state_payload(payload) -> StatePacket:
    data = bytes(payload)
    if len(data) != STATE_STRUCT.size:
        raise ValueError(f'payload size mismatch: got {len(data)}, expected {STATE_STRUCT.size}')
    magic, version, uav_id, state_seq, px4_ts, x, y, z, roll, pitch, yaw = STATE_STRUCT.unpack(data)
    if magic != MAGIC:
        raise ValueError(f'magic mismatch: got 0x{magic:04X}')
    if version != VERSION:
        raise ValueError(f'unsupported version: {version}')
    return StatePacket(uav_id, state_seq, px4_ts, x, y, z, roll, pitch, yaw)


class RemoteStateRxNode(Node):
    def __init__(self):
        super().__init__('remote_state_rx_node')

        self.uav_id = int(self.declare_parameter('uav_id', 1).value)
        self.peer_ids = parse_peer_ids(self.declare_parameter('peer_ids', '').value)
        self.jfi_rx_topic = str(self.declare_parameter('jfi_rx_topic', 'jfi_comm/out/packet').value)
        self.swarm_topic_prefix = str(self.declare_parameter('swarm_topic_prefix', '/swarm/uav').value)
        self.tid_state = int(self.declare_parameter('tid_state', 10).value)
        self.ignore_self = bool(self.declare_parameter('ignore_self', True).value)
        self.publish_known_peers = bool(self.declare_parameter('publish_known_peers', True).value)
        self.csv_log_path = str(self.declare_parameter('csv_log_path', '').value)
        self.print_debug = bool(self.declare_parameter('print_debug', True).value)

        self.pubs: Dict[int, rclpy.publisher.Publisher] = {}
        self.last_payload_seq: Dict[int, int] = {}
        self.csv_file = None
        self.csv_writer = None

        if self.publish_known_peers:
            for peer_id in self.peer_ids:
                if self.ignore_self and peer_id == self.uav_id:
                    continue
                self.get_or_create_pub(peer_id)

        self.setup_csv()
        self.sub = self.create_subscription(SwarmComm, self.jfi_rx_topic, self.on_jfi_packet, 10)

        self.get_logger().info(
            f'RemoteStateRxNode started: local_uav_id={self.uav_id}, peers={self.peer_ids}, '
            f'subscribe={self.jfi_rx_topic}, tid_state={self.tid_state}, csv={self.csv_log_path or "disabled"}'
        )

    def setup_csv(self):
        if not self.csv_log_path:
            return
        parent = os.path.dirname(self.csv_log_path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        file_exists = os.path.exists(self.csv_log_path) and os.path.getsize(self.csv_log_path) > 0
        self.csv_file = open(self.csv_log_path, 'a', newline='')
        self.csv_writer = csv.writer(self.csv_file)
        if not file_exists:
            self.csv_writer.writerow([
                'rx_wall_time_sec', 'local_uav_id', 'remote_uav_id', 'jfi_src_sysid', 'jfi_mavlink_seq',
                'remote_state_seq', 'dropped_since_last', 'px4_timestamp_us',
                'x_m', 'y_m', 'z_m', 'roll_rad', 'pitch_rad', 'yaw_rad'
            ])
            self.csv_file.flush()

    def get_or_create_pub(self, remote_uav_id: int):
        if remote_uav_id in self.pubs:
            return self.pubs[remote_uav_id]
        topic = f'{self.swarm_topic_prefix}{remote_uav_id}/state'
        pub = self.create_publisher(Float64MultiArray, topic, 10)
        self.pubs[remote_uav_id] = pub
        self.get_logger().info(f'Publishing REMOTE UAV{remote_uav_id} state to {topic}')
        return pub

    def on_jfi_packet(self, msg: SwarmComm):
        if int(msg.tid) != self.tid_state:
            return

        try:
            packet = decode_state_payload(msg.payload)
        except Exception as exc:
            self.get_logger().warn(f'Dropped J.Fi state packet: {exc}')
            return

        # The payload uav_id is the sender identity inserted by the remote bridge.
        remote_id = int(packet.uav_id)
        if self.ignore_self and remote_id == self.uav_id:
            return

        dropped = 0
        if remote_id in self.last_payload_seq:
            expected = (self.last_payload_seq[remote_id] + 1) & 0xFFFFFFFF
            if packet.state_seq != expected:
                if packet.state_seq > expected:
                    dropped = packet.state_seq - expected
                else:
                    dropped = -1  # wrap/out-of-order indicator
        self.last_payload_seq[remote_id] = packet.state_seq

        pub = self.get_or_create_pub(remote_id)
        out = Float64MultiArray()
        # data order: [remote_uav_id, px4_timestamp_us, x, y, z, roll, pitch, yaw, state_seq, dropped_since_last]
        out.data = [
            float(remote_id),
            float(packet.px4_timestamp_us),
            float(packet.x), float(packet.y), float(packet.z),
            float(packet.roll), float(packet.pitch), float(packet.yaw),
            float(packet.state_seq), float(dropped),
        ]
        pub.publish(out)

        if self.csv_writer is not None:
            self.csv_writer.writerow([
                f'{self.get_clock().now().nanoseconds / 1e9:.9f}',
                self.uav_id,
                remote_id,
                int(msg.src_sysid),       # MAVLink source sysid from serial_comm_node
                int(msg.seq),             # MAVLink packet seq from serial_comm_node
                int(packet.state_seq),    # state sequence inserted by remote TX node
                int(dropped),
                int(packet.px4_timestamp_us),
                f'{packet.x:.9f}', f'{packet.y:.9f}', f'{packet.z:.9f}',
                f'{packet.roll:.9f}', f'{packet.pitch:.9f}', f'{packet.yaw:.9f}',
            ])
            self.csv_file.flush()

        if self.print_debug:
            self.get_logger().info(
                f'RX remote UAV{remote_id}: seq={packet.state_seq}, x={packet.x:.2f}, y={packet.y:.2f}, z={packet.z:.2f}, dropped={dropped}'
            )

    def destroy_node(self):
        if self.csv_file is not None:
            self.csv_file.flush()
            self.csv_file.close()
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = RemoteStateRxNode()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
