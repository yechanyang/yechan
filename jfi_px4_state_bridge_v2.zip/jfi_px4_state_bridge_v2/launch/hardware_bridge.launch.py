from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    # Change these default_value fields per hardware and then rebuild/source.
    uav_id = LaunchConfiguration('uav_id')
    peer_ids = LaunchConfiguration('peer_ids')
    system_id = LaunchConfiguration('system_id')
    port_name = LaunchConfiguration('port_name')
    baud_rate = LaunchConfiguration('baud_rate')
    px4_odom_topic = LaunchConfiguration('px4_odom_topic')
    tid_state = LaunchConfiguration('tid_state')
    publish_hz = LaunchConfiguration('publish_hz')
    csv_log_path = LaunchConfiguration('csv_log_path')
    start_jfi_serial = LaunchConfiguration('start_jfi_serial')
    enable_tx = LaunchConfiguration('enable_tx')
    enable_rx = LaunchConfiguration('enable_rx')
    print_debug = LaunchConfiguration('print_debug')

    return LaunchDescription([
        DeclareLaunchArgument('uav_id', default_value='1'),
        DeclareLaunchArgument('peer_ids', default_value='2', description='Comma-separated remote UAV IDs, e.g. "2" or "2,3"'),
        DeclareLaunchArgument('system_id', default_value='1', description='J.Fi MAVLink system ID used by serial_comm_node'),
        DeclareLaunchArgument('port_name', default_value='/dev/ttyUSB0'),
        DeclareLaunchArgument('baud_rate', default_value='115200'),
        DeclareLaunchArgument('px4_odom_topic', default_value='/fmu/out/vehicle_odometry'),
        DeclareLaunchArgument('tid_state', default_value='10'),
        DeclareLaunchArgument('publish_hz', default_value='10.0'),
        DeclareLaunchArgument('csv_log_path', default_value='/home/uav01/jfi_logs/remote_state_log.csv'),
        DeclareLaunchArgument('start_jfi_serial', default_value='true'),
        DeclareLaunchArgument('enable_tx', default_value='true'),
        DeclareLaunchArgument('enable_rx', default_value='true'),
        DeclareLaunchArgument('print_debug', default_value='true'),

        # SUV-LAB node: owns the serial port and converts ROS SwarmComm <-> J.Fi MAVLink serial.
        Node(
            package='jfi_comm',
            executable='serial_comm_node',
            name='serial_comm_node',
            output='screen',
            condition=IfCondition(start_jfi_serial),
            parameters=[{
                'port_name': port_name,
                'baud_rate': baud_rate,
                'system_id': system_id,
            }],
        ),

        # TX only: local PX4 state -> /jfi_comm/in/packet.
        Node(
            package='jfi_px4_state_bridge',
            executable='local_state_tx_node.py',
            name='local_state_tx_node',
            output='screen',
            condition=IfCondition(enable_tx),
            parameters=[{
                'uav_id': uav_id,
                'px4_odom_topic': px4_odom_topic,
                'jfi_tx_topic': 'jfi_comm/in/packet',
                'tid_state': tid_state,
                'publish_hz': publish_hz,
                'enable_tx': True,
                'print_debug': False,
            }],
        ),

        # RX only: /jfi_comm/out/packet -> /swarm/uavX/state + CSV.
        # This logs only REMOTE UAV data, not local data.
        Node(
            package='jfi_px4_state_bridge',
            executable='remote_state_rx_node.py',
            name='remote_state_rx_node',
            output='screen',
            condition=IfCondition(enable_rx),
            parameters=[{
                'uav_id': uav_id,
                'peer_ids': peer_ids,
                'jfi_rx_topic': 'jfi_comm/out/packet',
                'swarm_topic_prefix': '/swarm/uav',
                'tid_state': tid_state,
                'ignore_self': True,
                'publish_known_peers': True,
                'csv_log_path': csv_log_path,
                'print_debug': print_debug,
            }],
        ),
    ])
