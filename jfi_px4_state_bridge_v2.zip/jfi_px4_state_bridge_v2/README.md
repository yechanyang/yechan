# jfi_px4_state_bridge v2

This package does not replace SUV-LAB `jfi_comm`. It uses it.

- `jfi_comm/serial_comm_node`: owns `/dev/ttyUSB*` and handles J.Fi MAVLink serial.
- `local_state_tx_node.py`: subscribes local PX4 `/fmu/out/vehicle_odometry` and publishes `jfi_comm/in/packet`.
- `remote_state_rx_node.py`: subscribes `jfi_comm/out/packet`, publishes `/swarm/uavX/state`, and logs only remote UAV state.

CSV logs contain remote UAV states only.
