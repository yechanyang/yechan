from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    # Set these default_value fields once per hardware.
    # UAV01 example: uav_id=1, system_id=1
    # UAV02 example: uav_id=2, system_id=2
    uav_id = LaunchConfiguration('uav_id')
    system_id = LaunchConfiguration('system_id')
    port_name = LaunchConfiguration('port_name')
    baud_rate = LaunchConfiguration('baud_rate')
    px4_odom_topic = LaunchConfiguration('px4_odom_topic')
    tid_state = LaunchConfiguration('tid_state')
    publish_hz = LaunchConfiguration('publish_hz')
    csv_log_path = LaunchConfiguration('csv_log_path')
    start_jfi_serial = LaunchConfiguration('start_jfi_serial')
    enable_tx = LaunchConfiguration('enable_tx')
    enable_rx = LaunchConfiguration('enable_rx')
    debug_print = LaunchConfiguration('debug_print')

    return LaunchDescription([
        # ---- Hardware-specific defaults ----
        DeclareLaunchArgument('uav_id', default_value='1'),
        DeclareLaunchArgument('system_id', default_value='1'),
        DeclareLaunchArgument('port_name', default_value='/dev/ttyUSB0'),
        DeclareLaunchArgument('baud_rate', default_value='115200'),
        DeclareLaunchArgument('px4_odom_topic', default_value='/fmu/out/vehicle_odometry'),
        DeclareLaunchArgument('tid_state', default_value='10'),
        DeclareLaunchArgument('publish_hz', default_value='10.0'),
        DeclareLaunchArgument('csv_log_path', default_value='/home/uav01/jfi_logs/uav{uav_id}_remote_state_{timestamp}.csv'),
        DeclareLaunchArgument('start_jfi_serial', default_value='true'),
        DeclareLaunchArgument('enable_tx', default_value='true'),
        DeclareLaunchArgument('enable_rx', default_value='true'),
        DeclareLaunchArgument('debug_print', default_value='true'),

        # 1) SUV-LAB node: owns /dev/ttyUSB0 and handles J-Fi serial I/O.
        Node(
            package='jfi_comm',
            executable='serial_comm_node',
            name='serial_comm_node',
            output='screen',
            condition=IfCondition(start_jfi_serial),
            parameters=[{
                'port_name': port_name,
                'baud_rate': baud_rate,
                'system_id': system_id,
            }],
        ),

        # 2) Local PX4 state -> /jfi_comm/in/packet.
        Node(
            package='jfi_px4_state_bridge',
            executable='px4_state_to_jfi_node.py',
            name='px4_state_to_jfi_node',
            output='screen',
            condition=IfCondition(enable_tx),
            parameters=[{
                'uav_id': uav_id,
                'px4_odom_topic': px4_odom_topic,
                'jfi_tx_topic': '/jfi_comm/in/packet',
                'tid_state': tid_state,
                'publish_hz': publish_hz,
                'enable_tx': True,
                'debug_print': False,
            }],
        ),

        # 3) /jfi_comm/out/packet -> /swarm/uav<N>/state + CSV logging.
        # No peer list is needed. The remote UAV number is read from the packet payload.
        Node(
            package='jfi_px4_state_bridge',
            executable='jfi_state_receiver_node.py',
            name='jfi_state_receiver_node',
            output='screen',
            condition=IfCondition(enable_rx),
            parameters=[{
                'uav_id': uav_id,
                'jfi_rx_topic': '/jfi_comm/out/packet',
                'swarm_topic_prefix': '/swarm/uav',
                'tid_state': tid_state,
                'ignore_self': True,
                'csv_log_path': csv_log_path,
                'debug_print': debug_print,
            }],
        ),
    ])
