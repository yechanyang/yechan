# jfi_px4_state_bridge odometry9

Simplified PX4 state bridge for SUV-LAB J-Fi N:N communication.

## Selected PX4 message

This version uses:

```text
/fmu/out/vehicle_odometry  (px4_msgs/msg/VehicleOdometry)
```

`VehicleOdometry` is used because it contains position, velocity, and attitude
quaternion in one timestamped estimator output. This avoids synchronizing
`VehicleLocalPosition` and `VehicleAttitude` separately.

## Nodes

1. `serial_comm_node` from `jfi_comm`
   - Opens the J-Fi serial port.
   - Subscribes `/jfi_comm/in/packet`.
   - Publishes `/jfi_comm/out/packet`.

2. `px4_state_to_jfi_node.py`
   - Subscribes `/fmu/out/vehicle_odometry`.
   - Extracts x, y, z, vx, vy, vz, roll, pitch, yaw.
   - Adds local `uav_id`.
   - Publishes `/jfi_comm/in/packet`.

3. `jfi_state_receiver_node.py`
   - Subscribes `/jfi_comm/out/packet`.
   - Ignores packets whose payload `uav_id` equals the local `uav_id`.
   - Publishes remote UAV states to `/swarm/uav<N>/state`.
   - Logs only remote UAV data to CSV.

## Topic data order

`/swarm/uav<N>/state` uses `std_msgs/Float64MultiArray`:

```text
[remote_uav_id, px4_timestamp_us,
 x, y, z,
 vx, vy, vz,
 roll, pitch, yaw,
 state_seq, dropped_since_last]
```

Coordinate convention is inherited from PX4 `VehicleOdometry`.
Usually this means NED-like local position/velocity depending on the message
`pose_frame` and `velocity_frame` fields.

## Run

```bash
ros2 launch jfi_px4_state_bridge hardware_bridge.launch.py
```
