#!/usr/bin/env python3
"""Publish local PX4 odometry state to SUV-LAB J-Fi packet topic.

This node does NOT open /dev/ttyUSB*. The actual J-Fi serial I/O is handled by
SUV-LAB's `serial_comm_node`.

Selected PX4 message:
  /fmu/out/vehicle_odometry  (px4_msgs/msg/VehicleOdometry)

Reason:
  VehicleOdometry already contains position, velocity, and attitude quaternion
  in one timestamped estimator output. This avoids synchronizing separate
  VehicleLocalPosition and VehicleAttitude topics.

Flow:
  PX4 /fmu/out/vehicle_odometry
      -> px4_state_to_jfi_node.py
      -> /jfi_comm/in/packet
      -> serial_comm_node
      -> J-Fi module
"""

import math
import struct
from typing import Sequence

import rclpy
from rclpy.node import Node
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy, DurabilityPolicy

from px4_msgs.msg import VehicleOdometry
from jfi_comm.msg import SwarmComm

# Payload format for state packets.
# Keep MAGIC/VERSION convention unchanged.
# magic: uint16 0x4A46 == 'JF' marker when interpreted consistently by sender/receiver
# version: uint8
# uav_id: uint8
# state_seq: uint32
# px4_timestamp_us: uint64
# x,y,z,vx,vy,vz,roll,pitch,yaw: float32
MAGIC = 0x4A46
VERSION = 1
STATE_STRUCT = struct.Struct('<HBBIQfffffffff')


def quat_wxyz_to_euler(q: Sequence[float]):
    """Convert PX4 VehicleOdometry quaternion [w, x, y, z] to roll/pitch/yaw [rad]."""
    w, x, y, z = float(q[0]), float(q[1]), float(q[2]), float(q[3])
    norm = math.sqrt(w*w + x*x + y*y + z*z)
    if norm < 1.0e-12 or not math.isfinite(norm):
        return float('nan'), float('nan'), float('nan')

    w, x, y, z = w / norm, x / norm, y / norm, z / norm

    sinr_cosp = 2.0 * (w*x + y*z)
    cosr_cosp = 1.0 - 2.0 * (x*x + y*y)
    roll = math.atan2(sinr_cosp, cosr_cosp)

    sinp = 2.0 * (w*y - z*x)
    if abs(sinp) >= 1.0:
        pitch = math.copysign(math.pi / 2.0, sinp)
    else:
        pitch = math.asin(sinp)

    siny_cosp = 2.0 * (w*z + x*y)
    cosy_cosp = 1.0 - 2.0 * (y*y + z*z)
    yaw = math.atan2(siny_cosp, cosy_cosp)

    return roll, pitch, yaw


def all_finite(values):
    """Return True only if all values are finite numbers."""
    return all(math.isfinite(float(v)) for v in values)


class Px4StateToJfiNode(Node):
    def __init__(self):
        super().__init__('px4_state_to_jfi_node')

        self.uav_id = int(self.declare_parameter('uav_id', 1).value)
        self.px4_odom_topic = str(
            self.declare_parameter('px4_odom_topic', '/fmu/out/vehicle_odometry').value
        )
        self.jfi_tx_topic = str(
            self.declare_parameter('jfi_tx_topic', '/jfi_comm/in/packet').value
        )
        self.tid_state = int(self.declare_parameter('tid_state', 10).value)
        self.publish_hz = float(self.declare_parameter('publish_hz', 10.0).value)
        self.enable_tx = bool(self.declare_parameter('enable_tx', True).value)
        self.debug_print = bool(self.declare_parameter('debug_print', False).value)
        self.drop_invalid = bool(self.declare_parameter('drop_invalid', True).value)

        if not (1 <= self.uav_id <= 255):
            raise RuntimeError('uav_id must be in [1, 255].')
        if not (0 <= self.tid_state <= 254):
            raise RuntimeError('tid_state must be in [0, 254]. TID 255 is reserved by jfi_comm fragmentation.')

        self.state_seq = 0
        self.last_tx_time_ns = None

        # Local ROS 2 topic to SUV-LAB serial_comm_node. Reliable default QoS is OK inside one CM4.
        self.jfi_pub = self.create_publisher(SwarmComm, self.jfi_tx_topic, 10)

        # PX4 /fmu/out topics generally require BEST_EFFORT + VOLATILE subscriber QoS.
        px4_sensor_qos = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            durability=DurabilityPolicy.VOLATILE,
            history=HistoryPolicy.KEEP_LAST,
            depth=5,
        )
        self.odom_sub = self.create_subscription(
            VehicleOdometry,
            self.px4_odom_topic,
            self.on_odometry,
            px4_sensor_qos,
        )

        self.get_logger().info(
            f'PX4->JFI TX started | local uav_id={self.uav_id}, '
            f'subscribe={self.px4_odom_topic}, publish={self.jfi_tx_topic}, '
            f'tid_state={self.tid_state}, publish_hz={self.publish_hz}, '
            f'payload_size={STATE_STRUCT.size} bytes'
        )

    def on_odometry(self, msg: VehicleOdometry):
        if not self.enable_tx:
            return

        now_ns = self.get_clock().now().nanoseconds
        if self.publish_hz > 0.0 and self.last_tx_time_ns is not None:
            period_ns = int(1.0e9 / self.publish_hz)
            if (now_ns - self.last_tx_time_ns) < period_ns:
                return
        self.last_tx_time_ns = now_ns

        roll, pitch, yaw = quat_wxyz_to_euler(msg.q)

        x = float(msg.position[0])
        y = float(msg.position[1])
        z = float(msg.position[2])
        vx = float(msg.velocity[0])
        vy = float(msg.velocity[1])
        vz = float(msg.velocity[2])

        if self.drop_invalid and not all_finite([x, y, z, vx, vy, vz, roll, pitch, yaw]):
            self.get_logger().warn('Invalid VehicleOdometry value. Skip J-Fi TX.', throttle_duration_sec=1.0)
            return

        payload = STATE_STRUCT.pack(
            MAGIC,
            VERSION,
            self.uav_id,
            self.state_seq,
            int(msg.timestamp),
            x,
            y,
            z,
            vx,
            vy,
            vz,
            float(roll),
            float(pitch),
            float(yaw),
        )

        out = SwarmComm()
        out.header.stamp = self.get_clock().now().to_msg()
        out.src_sysid = self.uav_id
        out.seq = self.state_seq
        out.tid = self.tid_state
        out.payload = list(payload)
        self.jfi_pub.publish(out)

        if self.debug_print and (self.state_seq % 20 == 0):
            self.get_logger().info(
                f'TX UAV{self.uav_id}: seq={self.state_seq}, '
                f'p=({x:.2f}, {y:.2f}, {z:.2f}), '
                f'v=({vx:.2f}, {vy:.2f}, {vz:.2f}), '
                f'rpy=({roll:.2f}, {pitch:.2f}, {yaw:.2f})'
            )

        self.state_seq = (self.state_seq + 1) & 0xFFFFFFFF


def main(args=None):
    rclpy.init(args=args)
    node = Px4StateToJfiNode()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
