#!/usr/bin/env python3
"""Receive SUV-LAB J-Fi odometry state packets and publish/log remote UAV states.

This node logs ONLY remote UAV data received through J-Fi. It does not log local
PX4 state.

Flow:
  J-Fi module
      -> serial_comm_node
      -> /jfi_comm/out/packet
      -> jfi_state_receiver_node.py
      -> /swarm/uav<N>/state
      -> timestamped CSV log
"""

import csv
import os
import struct
from dataclasses import dataclass
from datetime import datetime
from typing import Dict

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray

from jfi_comm.msg import SwarmComm

MAGIC = 0x4A46
VERSION = 1
# magic, version, uav_id, seq, timestamp, x,y,z,vx,vy,vz,roll,pitch,yaw
STATE_STRUCT = struct.Struct('<HBBIQfffffffff')


@dataclass
class StatePacket:
    uav_id: int
    state_seq: int
    px4_timestamp_us: int
    x: float
    y: float
    z: float
    vx: float
    vy: float
    vz: float
    roll: float
    pitch: float
    yaw: float


def decode_state_payload(payload) -> StatePacket:
    data = bytes(payload)
    if len(data) != STATE_STRUCT.size:
        raise ValueError(f'payload size mismatch: got {len(data)}, expected {STATE_STRUCT.size}')

    unpacked = STATE_STRUCT.unpack(data)
    magic, version, uav_id, state_seq, px4_ts = unpacked[:5]
    x, y, z, vx, vy, vz, roll, pitch, yaw = unpacked[5:]

    if magic != MAGIC:
        raise ValueError(f'magic mismatch: got 0x{magic:04X}, expected 0x{MAGIC:04X}')
    if version != VERSION:
        raise ValueError(f'version mismatch: got {version}, expected {VERSION}')

    return StatePacket(uav_id, state_seq, px4_ts, x, y, z, vx, vy, vz, roll, pitch, yaw)


def make_timestamped_csv_path(base_path: str, local_uav_id: int) -> str:
    """Return a new CSV path for each launch using current wall-clock time.

    Supported forms:
      ''                                      -> logging disabled
      '/home/uav01/jfi_logs/'                -> auto file inside directory
      '/home/uav01/jfi_logs/remote.csv'      -> remote_YYYYMMDD_HHMMSS.csv
      '/home/uav01/jfi_logs/uav{uav_id}_{timestamp}.csv'
    """
    if not base_path:
        return ''

    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    base_path = os.path.expanduser(base_path)

    if '{timestamp}' in base_path or '{uav_id}' in base_path:
        return base_path.format(timestamp=timestamp, uav_id=local_uav_id)

    if base_path.endswith(os.sep):
        return os.path.join(base_path, f'uav{local_uav_id:02d}_remote_state_{timestamp}.csv')

    parent = os.path.dirname(base_path)
    filename = os.path.basename(base_path)
    stem, ext = os.path.splitext(filename)
    if ext == '':
        ext = '.csv'
    return os.path.join(parent, f'{stem}_{timestamp}{ext}')


class JfiStateReceiverNode(Node):
    def __init__(self):
        super().__init__('jfi_state_receiver_node')

        self.uav_id = int(self.declare_parameter('uav_id', 1).value)
        self.jfi_rx_topic = str(self.declare_parameter('jfi_rx_topic', '/jfi_comm/out/packet').value)
        self.swarm_topic_prefix = str(self.declare_parameter('swarm_topic_prefix', '/swarm/uav').value)
        self.tid_state = int(self.declare_parameter('tid_state', 10).value)
        self.ignore_self = bool(self.declare_parameter('ignore_self', True).value)
        self.csv_log_path = str(self.declare_parameter('csv_log_path', '').value)
        self.debug_print = bool(self.declare_parameter('debug_print', True).value)

        self.pubs: Dict[int, rclpy.publisher.Publisher] = {}
        self.last_state_seq: Dict[int, int] = {}
        self.csv_file = None
        self.csv_writer = None

        self.setup_csv()
        self.sub = self.create_subscription(SwarmComm, self.jfi_rx_topic, self.on_jfi_packet, 10)

        self.get_logger().info(
            f'JFI RX started | local uav_id={self.uav_id}, subscribe={self.jfi_rx_topic}, '
            f'swarm_topic={self.swarm_topic_prefix}<remote_id>/state, tid_state={self.tid_state}, '
            f'payload_size={STATE_STRUCT.size} bytes, csv={self.csv_log_path or "disabled"}'
        )

    def setup_csv(self):
        if not self.csv_log_path:
            return

        self.csv_log_path = make_timestamped_csv_path(self.csv_log_path, self.uav_id)
        parent = os.path.dirname(self.csv_log_path)
        if parent:
            os.makedirs(parent, exist_ok=True)

        self.csv_file = open(self.csv_log_path, 'w', newline='')
        self.csv_writer = csv.writer(self.csv_file)
        self.csv_writer.writerow([
            'rx_wall_time_sec',
            'local_uav_id',
            'remote_uav_id',
            'jfi_src_sysid',
            'jfi_mavlink_seq',
            'remote_state_seq',
            'dropped_since_last',
            'px4_timestamp_us',
            'x_m',
            'y_m',
            'z_m',
            'vx_mps',
            'vy_mps',
            'vz_mps',
            'roll_rad',
            'pitch_rad',
            'yaw_rad',
        ])
        self.csv_file.flush()
        self.get_logger().info(f'CSV logging enabled: {self.csv_log_path}')

    def get_or_create_pub(self, remote_uav_id: int):
        if remote_uav_id in self.pubs:
            return self.pubs[remote_uav_id]

        topic = f'{self.swarm_topic_prefix}{remote_uav_id}/state'
        pub = self.create_publisher(Float64MultiArray, topic, 10)
        self.pubs[remote_uav_id] = pub
        self.get_logger().info(f'Created remote state topic: {topic}')
        return pub

    def on_jfi_packet(self, msg: SwarmComm):
        if int(msg.tid) != self.tid_state:
            return

        try:
            packet = decode_state_payload(msg.payload)
        except Exception as exc:
            self.get_logger().warn(f'Dropped non-state J-Fi packet: {exc}')
            return

        remote_id = int(packet.uav_id)
        if self.ignore_self and remote_id == self.uav_id:
            return

        dropped = 0
        if remote_id in self.last_state_seq:
            expected = (self.last_state_seq[remote_id] + 1) & 0xFFFFFFFF
            if packet.state_seq != expected:
                if packet.state_seq > expected:
                    dropped = int(packet.state_seq - expected)
                else:
                    dropped = -1  # wrap-around, duplicate, or out-of-order indicator
        self.last_state_seq[remote_id] = packet.state_seq

        pub = self.get_or_create_pub(remote_id)
        out = Float64MultiArray()
        # data order:
        # [remote_uav_id, px4_timestamp_us, x, y, z, vx, vy, vz,
        #  roll, pitch, yaw, state_seq, dropped_since_last]
        out.data = [
            float(remote_id),
            float(packet.px4_timestamp_us),
            float(packet.x),
            float(packet.y),
            float(packet.z),
            float(packet.vx),
            float(packet.vy),
            float(packet.vz),
            float(packet.roll),
            float(packet.pitch),
            float(packet.yaw),
            float(packet.state_seq),
            float(dropped),
        ]
        pub.publish(out)

        if self.csv_writer is not None:
            self.csv_writer.writerow([
                f'{self.get_clock().now().nanoseconds / 1e9:.9f}',
                self.uav_id,
                remote_id,
                int(msg.src_sysid),
                int(msg.seq),
                int(packet.state_seq),
                int(dropped),
                int(packet.px4_timestamp_us),
                f'{packet.x:.9f}',
                f'{packet.y:.9f}',
                f'{packet.z:.9f}',
                f'{packet.vx:.9f}',
                f'{packet.vy:.9f}',
                f'{packet.vz:.9f}',
                f'{packet.roll:.9f}',
                f'{packet.pitch:.9f}',
                f'{packet.yaw:.9f}',
            ])
            self.csv_file.flush()

        if self.debug_print:
            self.get_logger().info(
                f'RX remote UAV{remote_id}: seq={packet.state_seq}, '
                f'p=({packet.x:.2f}, {packet.y:.2f}, {packet.z:.2f}), '
                f'v=({packet.vx:.2f}, {packet.vy:.2f}, {packet.vz:.2f}), dropped={dropped}'
            )

    def destroy_node(self):
        if self.csv_file is not None:
            self.csv_file.flush()
            self.csv_file.close()
        super().destroy_node()


def main(args=None):
    rclpy.init(args=args)
    node = JfiStateReceiverNode()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
