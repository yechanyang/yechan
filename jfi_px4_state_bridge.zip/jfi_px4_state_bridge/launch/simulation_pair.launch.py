from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument, ExecuteProcess, TimerAction
from launch.substitutions import LaunchConfiguration, FindExecutable
from launch_ros.actions import Node


def generate_launch_description():
    args = [
        DeclareLaunchArgument('uav1_px4_prefix', default_value=''),
        DeclareLaunchArgument('uav2_px4_prefix', default_value='/px4_1'),
        DeclareLaunchArgument('publish_hz', default_value='10.0'),
        DeclareLaunchArgument('tid_state', default_value='10'),
        DeclareLaunchArgument('uav1_log', default_value='/tmp/uav1_jfi_state_log.csv'),
        DeclareLaunchArgument('uav2_log', default_value='/tmp/uav2_jfi_state_log.csv'),
    ]

    socat_process = ExecuteProcess(
        cmd=[
            FindExecutable(name='socat'),
            'PTY,link=/tmp/jfi_uav1,raw,echo=0',
            'PTY,link=/tmp/jfi_uav2,raw,echo=0',
        ],
        output='screen',
    )

    uav1_jfi = Node(
        package='jfi_comm',
        executable='serial_comm_node',
        namespace='uav1',
        name='serial_comm_node',
        output='screen',
        parameters=[{'port_name': '/tmp/jfi_uav1', 'baud_rate': 115200, 'system_id': 1, 'component_id': 1}],
    )

    uav2_jfi = Node(
        package='jfi_comm',
        executable='serial_comm_node',
        namespace='uav2',
        name='serial_comm_node',
        output='screen',
        parameters=[{'port_name': '/tmp/jfi_uav2', 'baud_rate': 115200, 'system_id': 2, 'component_id': 1}],
    )

    uav1_bridge = Node(
        package='jfi_px4_state_bridge',
        executable='px4_state_jfi_bridge_node',
        namespace='uav1',
        name='px4_state_jfi_bridge_node',
        output='screen',
        parameters=[{
            'uav_id': 1,
            'px4_prefix': LaunchConfiguration('uav1_px4_prefix'),
            'publish_hz': LaunchConfiguration('publish_hz'),
            'tid_state': LaunchConfiguration('tid_state'),
            'csv_log_path': LaunchConfiguration('uav1_log'),
            # These are relative names, so they become /uav1/jfi_comm/...
            'jfi_tx_topic': 'jfi_comm/in/packet',
            'jfi_rx_topic': 'jfi_comm/out/packet',
            # Keep remote-state topics global for easy echo.
            'swarm_topic_prefix': '/swarm/uav',
        }],
    )

    uav2_bridge = Node(
        package='jfi_px4_state_bridge',
        executable='px4_state_jfi_bridge_node',
        namespace='uav2',
        name='px4_state_jfi_bridge_node',
        output='screen',
        parameters=[{
            'uav_id': 2,
            'px4_prefix': LaunchConfiguration('uav2_px4_prefix'),
            'publish_hz': LaunchConfiguration('publish_hz'),
            'tid_state': LaunchConfiguration('tid_state'),
            'csv_log_path': LaunchConfiguration('uav2_log'),
            'jfi_tx_topic': 'jfi_comm/in/packet',
            'jfi_rx_topic': 'jfi_comm/out/packet',
            'swarm_topic_prefix': '/swarm/uav',
        }],
    )

    delayed_nodes = TimerAction(period=1.0, actions=[uav1_jfi, uav2_jfi, uav1_bridge, uav2_bridge])

    return LaunchDescription(args + [socat_process, delayed_nodes])
