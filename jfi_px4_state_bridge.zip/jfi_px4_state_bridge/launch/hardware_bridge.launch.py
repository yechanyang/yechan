from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.conditions import IfCondition
from launch.substitutions import LaunchConfiguration
from launch_ros.actions import Node


def generate_launch_description():
    args = [
        DeclareLaunchArgument('uav_id', default_value='1'),
        DeclareLaunchArgument('port_name', default_value='/dev/ttyUSB0'),
        DeclareLaunchArgument('baud_rate', default_value='115200'),
        DeclareLaunchArgument('system_id', default_value='1'),
        DeclareLaunchArgument('component_id', default_value='1'),
        DeclareLaunchArgument('px4_prefix', default_value=''),
        DeclareLaunchArgument('publish_hz', default_value='10.0'),
        DeclareLaunchArgument('tid_state', default_value='10'),
        DeclareLaunchArgument('csv_log_path', default_value=''),
        DeclareLaunchArgument('start_jfi_serial', default_value='true'),
    ]

    jfi_serial_node = Node(
        package='jfi_comm',
        executable='serial_comm_node',
        name='serial_comm_node',
        output='screen',
        condition=IfCondition(LaunchConfiguration('start_jfi_serial')),
        parameters=[{
            'port_name': LaunchConfiguration('port_name'),
            'baud_rate': LaunchConfiguration('baud_rate'),
            'system_id': LaunchConfiguration('system_id'),
            'component_id': LaunchConfiguration('component_id'),
        }],
    )

    bridge_node = Node(
        package='jfi_px4_state_bridge',
        executable='px4_state_jfi_bridge_node',
        name='px4_state_jfi_bridge_node',
        output='screen',
        parameters=[{
            'uav_id': LaunchConfiguration('uav_id'),
            'px4_prefix': LaunchConfiguration('px4_prefix'),
            'publish_hz': LaunchConfiguration('publish_hz'),
            'tid_state': LaunchConfiguration('tid_state'),
            'csv_log_path': LaunchConfiguration('csv_log_path'),
        }],
    )

    return LaunchDescription(args + [jfi_serial_node, bridge_node])
