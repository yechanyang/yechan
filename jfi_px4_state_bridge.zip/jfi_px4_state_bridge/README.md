# jfi_px4_state_bridge

This package does not open the J-Fi serial port directly. It uses the existing SUV-Lab `jfi_comm` package:

- TX path: `/fmu/out/vehicle_odometry` -> `jfi_comm/msg/SwarmComm` -> `jfi_comm/in/packet` -> `jfi_comm::serial_comm_node` -> J-Fi serial/MAVLink packet
- RX path: J-Fi serial/MAVLink packet -> `jfi_comm::serial_comm_node` -> `jfi_comm/out/packet` -> `/swarm/uav<N>/state` + CSV log

The transmitted payload is a compact 40-byte binary state packet:

```text
uint16 magic = 0x4A46
uint8  version = 1
uint8  uav_id
uint32 seq
uint64 px4_timestamp_us
float32 x, y, z, roll, pitch, yaw
```

`/swarm/uav<N>/state` is `std_msgs/msg/Float64MultiArray`:

```text
data = [uav_id, px4_timestamp_us, x, y, z, roll, pitch, yaw]
```

PX4 `VehicleOdometry.position` is normally in the local NED convention. Angles are radians, converted from `VehicleOdometry.q = [w, x, y, z]`.

## Build

Place this package next to `jfi_comm`, `mavlink_vendor`, `px4_msgs`, and your own ROS2 packages:

```bash
cd ~/uav01_ros2
rm -rf build/jfi_px4_state_bridge install/jfi_px4_state_bridge log
colcon build --symlink-install --packages-select jfi_px4_state_bridge
source install/setup.bash
```

If the old generated Python package `jfi_swarm_bridge` is still in `src`, remove it or skip it because it can fail with `setup.py: option --editable not recognized` on some colcon/setuptools combinations:

```bash
rm -rf ~/uav01_ros2/src/jfi_swarm_bridge
# or
colcon build --symlink-install --packages-skip jfi_swarm_bridge
```

## Hardware example

UAV1:

```bash
ros2 launch jfi_px4_state_bridge hardware_bridge.launch.py \
  uav_id:=1 system_id:=1 port_name:=/dev/ttyUSB0 baud_rate:=115200 \
  csv_log_path:=/home/uav01/jfi_logs/uav1_state_log.csv
```

UAV2:

```bash
ros2 launch jfi_px4_state_bridge hardware_bridge.launch.py \
  uav_id:=2 system_id:=2 port_name:=/dev/ttyUSB0 baud_rate:=115200 \
  csv_log_path:=/home/uav02/jfi_logs/uav2_state_log.csv
```

Check received remote state:

```bash
ros2 topic echo /swarm/uav1/state
ros2 topic echo /swarm/uav2/state
```

## Simulation pair using socat

```bash
sudo apt install socat
ros2 launch jfi_px4_state_bridge simulation_pair.launch.py \
  uav1_px4_prefix:="" uav2_px4_prefix:="/px4_1"
```

Adjust `uav*_px4_prefix` to match your actual PX4 multi-vehicle topic names.
