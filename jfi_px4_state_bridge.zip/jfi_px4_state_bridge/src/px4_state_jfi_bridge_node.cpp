#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <limits>
#include <map>
#include <memory>
#include <string>
#include <vector>

#include <rclcpp/rclcpp.hpp>
#include <std_msgs/msg/float64_multi_array.hpp>
#include <px4_msgs/msg/vehicle_odometry.hpp>
#include <jfi_comm/msg/swarm_comm.hpp>

namespace
{
constexpr uint16_t kMagic = 0x4a46;  // ASCII "JF" in little endian payload convention.
constexpr uint8_t kVersion = 1;
constexpr size_t kStatePayloadSize = 40;

struct StatePacket
{
  uint8_t uav_id{0};
  uint32_t seq{0};
  uint64_t timestamp_us{0};
  float x{0.0F};
  float y{0.0F};
  float z{0.0F};
  float roll{0.0F};
  float pitch{0.0F};
  float yaw{0.0F};
};

void append_u8(std::vector<uint8_t> & out, uint8_t value)
{
  out.push_back(value);
}

void append_u16_le(std::vector<uint8_t> & out, uint16_t value)
{
  out.push_back(static_cast<uint8_t>(value & 0xffU));
  out.push_back(static_cast<uint8_t>((value >> 8U) & 0xffU));
}

void append_u32_le(std::vector<uint8_t> & out, uint32_t value)
{
  for (int i = 0; i < 4; ++i) {
    out.push_back(static_cast<uint8_t>((value >> (8 * i)) & 0xffU));
  }
}

void append_u64_le(std::vector<uint8_t> & out, uint64_t value)
{
  for (int i = 0; i < 8; ++i) {
    out.push_back(static_cast<uint8_t>((value >> (8 * i)) & 0xffU));
  }
}

void append_f32_le(std::vector<uint8_t> & out, float value)
{
  static_assert(sizeof(float) == sizeof(uint32_t), "float must be 32-bit");
  uint32_t bits = 0;
  std::memcpy(&bits, &value, sizeof(float));
  append_u32_le(out, bits);
}

bool read_u8(const std::vector<uint8_t> & data, size_t & offset, uint8_t & value)
{
  if (offset + 1U > data.size()) {
    return false;
  }
  value = data[offset++];
  return true;
}

bool read_u16_le(const std::vector<uint8_t> & data, size_t & offset, uint16_t & value)
{
  if (offset + 2U > data.size()) {
    return false;
  }
  value = static_cast<uint16_t>(data[offset]) |
    static_cast<uint16_t>(static_cast<uint16_t>(data[offset + 1U]) << 8U);
  offset += 2U;
  return true;
}

bool read_u32_le(const std::vector<uint8_t> & data, size_t & offset, uint32_t & value)
{
  if (offset + 4U > data.size()) {
    return false;
  }
  value = 0;
  for (int i = 0; i < 4; ++i) {
    value |= static_cast<uint32_t>(data[offset + static_cast<size_t>(i)]) << (8U * i);
  }
  offset += 4U;
  return true;
}

bool read_u64_le(const std::vector<uint8_t> & data, size_t & offset, uint64_t & value)
{
  if (offset + 8U > data.size()) {
    return false;
  }
  value = 0;
  for (int i = 0; i < 8; ++i) {
    value |= static_cast<uint64_t>(data[offset + static_cast<size_t>(i)]) << (8U * i);
  }
  offset += 8U;
  return true;
}

bool read_f32_le(const std::vector<uint8_t> & data, size_t & offset, float & value)
{
  uint32_t bits = 0;
  if (!read_u32_le(data, offset, bits)) {
    return false;
  }
  std::memcpy(&value, &bits, sizeof(float));
  return true;
}

std::vector<uint8_t> encode_state_packet(const StatePacket & packet)
{
  std::vector<uint8_t> out;
  out.reserve(kStatePayloadSize);
  append_u16_le(out, kMagic);
  append_u8(out, kVersion);
  append_u8(out, packet.uav_id);
  append_u32_le(out, packet.seq);
  append_u64_le(out, packet.timestamp_us);
  append_f32_le(out, packet.x);
  append_f32_le(out, packet.y);
  append_f32_le(out, packet.z);
  append_f32_le(out, packet.roll);
  append_f32_le(out, packet.pitch);
  append_f32_le(out, packet.yaw);
  return out;
}

bool decode_state_packet(const std::vector<uint8_t> & payload, StatePacket & packet, std::string & reason)
{
  if (payload.size() != kStatePayloadSize) {
    reason = "payload size mismatch: " + std::to_string(payload.size());
    return false;
  }

  size_t offset = 0;
  uint16_t magic = 0;
  uint8_t version = 0;

  if (!read_u16_le(payload, offset, magic) || !read_u8(payload, offset, version)) {
    reason = "header too short";
    return false;
  }

  if (magic != kMagic) {
    reason = "magic mismatch";
    return false;
  }
  if (version != kVersion) {
    reason = "unsupported version: " + std::to_string(version);
    return false;
  }

  bool ok = true;
  ok = ok && read_u8(payload, offset, packet.uav_id);
  ok = ok && read_u32_le(payload, offset, packet.seq);
  ok = ok && read_u64_le(payload, offset, packet.timestamp_us);
  ok = ok && read_f32_le(payload, offset, packet.x);
  ok = ok && read_f32_le(payload, offset, packet.y);
  ok = ok && read_f32_le(payload, offset, packet.z);
  ok = ok && read_f32_le(payload, offset, packet.roll);
  ok = ok && read_f32_le(payload, offset, packet.pitch);
  ok = ok && read_f32_le(payload, offset, packet.yaw);

  if (!ok || offset != payload.size()) {
    reason = "payload parse failed";
    return false;
  }
  return true;
}

std::array<double, 3> quat_wxyz_to_euler(const std::array<float, 4> & q)
{
  double w = static_cast<double>(q[0]);
  double x = static_cast<double>(q[1]);
  double y = static_cast<double>(q[2]);
  double z = static_cast<double>(q[3]);

  const double norm = std::sqrt(w * w + x * x + y * y + z * z);
  if (norm < 1.0e-12 || !std::isfinite(norm)) {
    const double nan = std::numeric_limits<double>::quiet_NaN();
    return {nan, nan, nan};
  }

  w /= norm;
  x /= norm;
  y /= norm;
  z /= norm;

  const double sinr_cosp = 2.0 * (w * x + y * z);
  const double cosr_cosp = 1.0 - 2.0 * (x * x + y * y);
  const double roll = std::atan2(sinr_cosp, cosr_cosp);

  const double sinp = 2.0 * (w * y - z * x);
  double pitch = 0.0;
  if (std::abs(sinp) >= 1.0) {
    pitch = std::copysign(M_PI / 2.0, sinp);
  } else {
    pitch = std::asin(sinp);
  }

  const double siny_cosp = 2.0 * (w * z + x * y);
  const double cosy_cosp = 1.0 - 2.0 * (y * y + z * z);
  const double yaw = std::atan2(siny_cosp, cosy_cosp);

  return {roll, pitch, yaw};
}

std::string join_topic(const std::string & prefix, const std::string & suffix)
{
  std::string p = prefix;
  std::string s = suffix;
  if (s.empty() || s[0] != '/') {
    s = "/" + s;
  }
  if (p.empty()) {
    return s;
  }
  if (p[0] != '/') {
    p = "/" + p;
  }
  while (!p.empty() && p.back() == '/') {
    p.pop_back();
  }
  return p + s;
}

bool file_exists_and_nonempty(const std::string & path)
{
  std::error_code ec;
  return std::filesystem::exists(path, ec) && std::filesystem::file_size(path, ec) > 0;
}

}  // namespace

class Px4StateJfiBridge : public rclcpp::Node
{
public:
  Px4StateJfiBridge()
  : Node("px4_state_jfi_bridge_node")
  {
    uav_id_ = declare_parameter<int>("uav_id", 1);
    px4_prefix_ = declare_parameter<std::string>("px4_prefix", "");
    local_odom_topic_suffix_ = declare_parameter<std::string>("local_odom_topic", "/fmu/out/vehicle_odometry");
    jfi_tx_topic_ = declare_parameter<std::string>("jfi_tx_topic", "jfi_comm/in/packet");
    jfi_rx_topic_ = declare_parameter<std::string>("jfi_rx_topic", "jfi_comm/out/packet");
    swarm_topic_prefix_ = declare_parameter<std::string>("swarm_topic_prefix", "/swarm/uav");
    tid_state_ = declare_parameter<int>("tid_state", 10);
    publish_hz_ = declare_parameter<double>("publish_hz", 10.0);
    enable_tx_ = declare_parameter<bool>("enable_tx", true);
    enable_rx_ = declare_parameter<bool>("enable_rx", true);
    ignore_self_ = declare_parameter<bool>("ignore_self", true);
    log_tx_ = declare_parameter<bool>("log_tx", true);
    log_rx_ = declare_parameter<bool>("log_rx", true);
    csv_log_path_ = declare_parameter<std::string>("csv_log_path", "");

    if (uav_id_ < 1 || uav_id_ > 255) {
      throw std::runtime_error("uav_id must be in [1, 255]");
    }
    if (tid_state_ < 0 || tid_state_ > 254) {
      throw std::runtime_error("tid_state must be in [0, 254]. TID 255 is reserved by jfi_comm fragmentation.");
    }

    setup_logger();

    jfi_tx_pub_ = create_publisher<jfi_comm::msg::SwarmComm>(jfi_tx_topic_, 10);

    if (enable_rx_) {
      jfi_rx_sub_ = create_subscription<jfi_comm::msg::SwarmComm>(
        jfi_rx_topic_, 10, std::bind(&Px4StateJfiBridge::on_jfi_packet, this, std::placeholders::_1));
    }

    if (enable_tx_) {
      const std::string odom_topic = join_topic(px4_prefix_, local_odom_topic_suffix_);
      odom_sub_ = create_subscription<px4_msgs::msg::VehicleOdometry>(
        odom_topic, rclcpp::SensorDataQoS(),
        std::bind(&Px4StateJfiBridge::on_vehicle_odometry, this, std::placeholders::_1));
      RCLCPP_INFO(get_logger(), "Subscribing PX4 odometry: %s", odom_topic.c_str());
    }

    RCLCPP_INFO(
      get_logger(),
      "J.Fi PX4 state bridge started. uav_id=%d, tid_state=%d, jfi_tx_topic=%s, jfi_rx_topic=%s, publish_hz=%.2f",
      uav_id_, tid_state_, jfi_tx_topic_.c_str(), jfi_rx_topic_.c_str(), publish_hz_);
  }

  ~Px4StateJfiBridge() override
  {
    if (csv_file_.is_open()) {
      csv_file_.flush();
      csv_file_.close();
    }
  }

private:
  void setup_logger()
  {
    if (csv_log_path_.empty()) {
      return;
    }

    std::filesystem::path path(csv_log_path_);
    if (!path.parent_path().empty()) {
      std::error_code ec;
      std::filesystem::create_directories(path.parent_path(), ec);
      if (ec) {
        RCLCPP_WARN(get_logger(), "Failed to create log directory: %s", ec.message().c_str());
      }
    }

    const bool already_has_data = file_exists_and_nonempty(csv_log_path_);
    csv_file_.open(csv_log_path_, std::ios::out | std::ios::app);
    if (!csv_file_.is_open()) {
      RCLCPP_WARN(get_logger(), "Failed to open CSV log file: %s", csv_log_path_.c_str());
      return;
    }
    if (!already_has_data) {
      csv_file_ << "wall_time_sec,direction,src_uav_id,seq,px4_timestamp_us,"
                << "x_m,y_m,z_m,roll_rad,pitch_rad,yaw_rad\n";
      csv_file_.flush();
    }
  }

  void on_vehicle_odometry(const px4_msgs::msg::VehicleOdometry::SharedPtr msg)
  {
    const auto now = steady_clock_.now();
    if (publish_hz_ > 0.0) {
      const double elapsed = (now - last_tx_time_).seconds();
      if (has_tx_time_ && elapsed < (1.0 / publish_hz_)) {
        return;
      }
    }
    last_tx_time_ = now;
    has_tx_time_ = true;

    const auto euler = quat_wxyz_to_euler(msg->q);

    StatePacket packet;
    packet.uav_id = static_cast<uint8_t>(uav_id_);
    packet.seq = tx_seq_++;
    packet.timestamp_us = static_cast<uint64_t>(msg->timestamp);
    packet.x = msg->position[0];
    packet.y = msg->position[1];
    packet.z = msg->position[2];
    packet.roll = static_cast<float>(euler[0]);
    packet.pitch = static_cast<float>(euler[1]);
    packet.yaw = static_cast<float>(euler[2]);

    auto out = jfi_comm::msg::SwarmComm();
    out.header.stamp = this->now();
    out.src_sysid = static_cast<uint8_t>(uav_id_);
    out.seq = packet.seq;
    out.tid = static_cast<uint8_t>(tid_state_);
    out.payload = encode_state_packet(packet);
    jfi_tx_pub_->publish(out);

    if (log_tx_) {
      log_packet("tx", packet);
    }
  }

  void on_jfi_packet(const jfi_comm::msg::SwarmComm::SharedPtr msg)
  {
    if (msg->tid != static_cast<uint8_t>(tid_state_)) {
      return;
    }

    StatePacket packet;
    std::string reason;
    if (!decode_state_packet(msg->payload, packet, reason)) {
      RCLCPP_WARN_THROTTLE(get_logger(), *get_clock(), 3000, "Dropped J.Fi state packet: %s", reason.c_str());
      return;
    }

    if (ignore_self_ && static_cast<int>(packet.uav_id) == uav_id_) {
      return;
    }

    const auto pub = get_or_create_swarm_publisher(packet.uav_id);
    auto out = std_msgs::msg::Float64MultiArray();
    out.data = {
      static_cast<double>(packet.uav_id),
      static_cast<double>(packet.timestamp_us),
      static_cast<double>(packet.x),
      static_cast<double>(packet.y),
      static_cast<double>(packet.z),
      static_cast<double>(packet.roll),
      static_cast<double>(packet.pitch),
      static_cast<double>(packet.yaw)};
    pub->publish(out);

    if (log_rx_) {
      log_packet("rx", packet);
    }
  }

  rclcpp::Publisher<std_msgs::msg::Float64MultiArray>::SharedPtr get_or_create_swarm_publisher(uint8_t src_uav_id)
  {
    const auto key = static_cast<int>(src_uav_id);
    const auto it = swarm_pubs_.find(key);
    if (it != swarm_pubs_.end()) {
      return it->second;
    }

    std::string topic = swarm_topic_prefix_ + std::to_string(key) + "/state";
    auto pub = create_publisher<std_msgs::msg::Float64MultiArray>(topic, 10);
    swarm_pubs_[key] = pub;
    RCLCPP_INFO(get_logger(), "Publishing remote UAV%d state to %s", key, topic.c_str());
    return pub;
  }

  void log_packet(const std::string & direction, const StatePacket & packet)
  {
    if (!csv_file_.is_open()) {
      return;
    }
    csv_file_ << std::fixed
              << now().seconds() << ','
              << direction << ','
              << static_cast<int>(packet.uav_id) << ','
              << packet.seq << ','
              << packet.timestamp_us << ','
              << packet.x << ','
              << packet.y << ','
              << packet.z << ','
              << packet.roll << ','
              << packet.pitch << ','
              << packet.yaw << '\n';
    csv_file_.flush();
  }

  int uav_id_{1};
  std::string px4_prefix_;
  std::string local_odom_topic_suffix_;
  std::string jfi_tx_topic_;
  std::string jfi_rx_topic_;
  std::string swarm_topic_prefix_;
  int tid_state_{10};
  double publish_hz_{10.0};
  bool enable_tx_{true};
  bool enable_rx_{true};
  bool ignore_self_{true};
  bool log_tx_{true};
  bool log_rx_{true};
  std::string csv_log_path_;

  uint32_t tx_seq_{0};
  rclcpp::Clock steady_clock_{RCL_STEADY_TIME};
  rclcpp::Time last_tx_time_{0, 0, RCL_STEADY_TIME};
  bool has_tx_time_{false};

  rclcpp::Subscription<px4_msgs::msg::VehicleOdometry>::SharedPtr odom_sub_;
  rclcpp::Publisher<jfi_comm::msg::SwarmComm>::SharedPtr jfi_tx_pub_;
  rclcpp::Subscription<jfi_comm::msg::SwarmComm>::SharedPtr jfi_rx_sub_;
  std::map<int, rclcpp::Publisher<std_msgs::msg::Float64MultiArray>::SharedPtr> swarm_pubs_;

  std::ofstream csv_file_;
};

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  try {
    rclcpp::spin(std::make_shared<Px4StateJfiBridge>());
  } catch (const std::exception & e) {
    RCLCPP_FATAL(rclcpp::get_logger("px4_state_jfi_bridge_node"), "Unhandled exception: %s", e.what());
  }
  rclcpp::shutdown();
  return 0;
}
